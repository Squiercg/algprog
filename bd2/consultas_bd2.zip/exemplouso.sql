use Empresa;
call chefe_departamento(NULL,'Matriz');
use Universidade;
call consulta_disciplina('CCT620',NULL);
use Empresa;
call altera_data(12345,'1981-05-26');