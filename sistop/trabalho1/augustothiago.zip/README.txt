O trabalho contem um make, que faz a compilação e inicia o programa.
