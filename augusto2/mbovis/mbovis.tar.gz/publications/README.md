This is the github repository of bibtexbrowser.

It is used to collect patches and extensions as pull requests.

The official home page of bibtexbrowser is <http://www.monperrus.net/martin/bibtexbrowser/>.

Bibtexbrowser is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.
