<?php
$username="tuberculosis";
$password="tuberculose&Humadoenca";
$database="tuberculosis";
?>

